// export enum ROLE {
//     Admin = 'Admin',
//     User = 'User',
// }
let ROLE = {}
export default  ROLE = {
    ADMIN: "ADMIN",
    USER: "USER",
}